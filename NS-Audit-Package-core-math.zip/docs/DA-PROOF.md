# DA proof — name a problem, get the chain

The operator is not a math person. They name a problem.
DA writes the aimed theorem and the proof chain from
the ground floor.

```
python3 scripts/da_machine.py proof
python3 scripts/da_machine.py proof --problem NS
python3 scripts/da_machine.py proof --problem A
python3 scripts/da_machine.py proof --problem RH
python3 scripts/da_machine.py proof --problem YM
python3 scripts/da_machine.py next --ask "write me the proof chain for Navier-Stokes"
python3 scripts/da_machine.py next --ask "RH proof chain please"
python3 scripts/da_machine.py next --ask "Track B please write"
python3 scripts/da_machine.py next --ask "Please finish bad for me please. So I can complete proof chain"
python3 scripts/da_machine.py next --ask "track A write"
python3 scripts/da_machine.py next --ask "Track B please write. track A write as well"
python3 scripts/da_machine.py next --ask "use my best paper and write RH"
python3 scripts/da_machine.py next --ask "Yang mills and bad can you finish those"
python3 scripts/da_machine.py proof --problem BSD
python3 scripts/da_machine.py next --ask "Please write BSD"
python3 scripts/da_machine.py next --ask "spectral framework"
python3 scripts/da_machine.py next --ask "BSD final"
python3 scripts/da_machine.py proof --problem HODGE
python3 scripts/da_machine.py next --ask "Hodge conjecture?"
python3 scripts/da_machine.py proof --problem POINCARE
python3 scripts/da_machine.py next --ask "point care conjecture"
python3 scripts/da_machine.py proof --problem PNP
python3 scripts/da_machine.py next --ask "P versus NP"
python3 scripts/da_machine.py proof --problem ALL
python3 scripts/da_machine.py next --ask "Please write the final, corrected and complete versions"
python3 scripts/da_machine.py pack
python3 scripts/da_machine.py next --ask "give them to me in like a PDF"
```

Nothing is wrong with asking. That is the product.

| Problem | Command | Chain |
|---|---|---|
| Navier–Stokes / Track B | `--problem NS` or `Track B please write` | [`NS-PROOF-CHAIN.md`](NS-PROOF-CHAIN.md) |
| \(Q_1\) / Track A | `--problem A` or `track A write` | [`A-PROOF-CHAIN.md`](A-PROOF-CHAIN.md) |
| Riemann hypothesis | `--problem RH` | [`RH-PROOF-CHAIN.md`](RH-PROOF-CHAIN.md) |
| Yang–Mills mass gap | `--problem YM` or `Yang mills and bad` | [`YM-PROOF-CHAIN.md`](YM-PROOF-CHAIN.md) |
| Birch–Swinnerton-Dyer | `--problem BSD` or `Please write BSD` / `spectral framework` / `BSD final` | [`BSD-PROOF-CHAIN.md`](BSD-PROOF-CHAIN.md) |
| Hodge conjecture | `--problem HODGE` or `Hodge conjecture?` | [`HODGE-PROOF-CHAIN.md`](HODGE-PROOF-CHAIN.md) |
| Poincaré conjecture | `--problem POINCARE` or `point care` | [`POINCARE-PROOF-CHAIN.md`](POINCARE-PROOF-CHAIN.md) |
| P versus NP | `--problem PNP` or `P versus NP` | [`PNP-PROOF-CHAIN.md`](PNP-PROOF-CHAIN.md) |
| All seated chains (exam) | `--problem ALL` or `final, corrected and complete versions` | [`DA-COMPLETE.md`](DA-COMPLETE.md) |

Track A is the \(Q_1\) PDE. Theorem A already sits for
that equation. Track B is classical NS. Do not glue.
Track Q is inverse-GCD. It is not RH. It is not BSD. It is not Hodge. Do not glue.
\(L(E,s)\) is not zeta. `BSD final.pdf` is not the Hodge conjecture.

The WRITE line is the attempt. Emitting the chain is
not QED. If WRITE sits, the THEN lines are the close.
`done` answers whether that emit is a finish:
[`DA-DONE.md`](DA-DONE.md). Track A this PDE is done.
Classical NS is not.

More problems may join when a ground-floor chain is typed.

Already have A / SND / H work and want the fault plus the repair write: [`DA-REPAIR.md`](DA-REPAIR.md). `python3 scripts/da_machine.py repair --job A`.

Best A (Q1 + renormalization) and furthest RH, dream team looking, legal write: [`DA-ATTEMPT.md`](DA-ATTEMPT.md). `python3 scripts/da_machine.py attempt`.

---

## Scored

| Claim | Verdict |
|---|---|
| You can tell DA to write a proof chain by naming the problem | **pass** |
| The written chain is the aimed theorem plus have / write / follows | **pass** |
| Emitting the proof chain is QED | **fail** |
| An LLM writes the WRITE line into a theorem | **fail** |
| Asking DA to write a proof chain is a category error | **fail** |
| Track Q / Theorem P is the Riemann hypothesis | **fail** |
| Theorem A is classical Navier–Stokes | **fail** |
| Please finish bad closes leftover (6) | **fail** |
| `BSD final.pdf` is the Hodge conjecture | **fail** |
| SFE harmonic \(H(x)\) proves \(\mathrm{P}\neq\mathrm{NP}\) | **fail** |
| Writing the complete versions closes the leftovers | **fail** |
| Document that DA completed BSD leftover (6) and closed it out | **fail** |
| SFE harmonic coherence proves Hodge | **fail** |
| Naming the WRITE line means DA filled the gap | **fail** |
| A completed RH close exists and is being withheld | **fail** |
| Poincaré is still an open WRITE | **fail** |
| The WRITE line may sit later | **open** |
| More named problems may get a ground-floor chain | **open** |
