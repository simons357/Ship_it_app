# Unrestricted Lemma★ — growing-layer family

12 September 2026.
Unaugmented Navier–Stokes on \(\mathbb{T}^3\);
quantity is the locked
\(\mathcal R_\star=(T_c)_+^2/(\mathcal D_s E Y)\);
the family below is divergence-free, real, mean-zero,
finite Fourier support, \(\mathcal D_s>0\);
**unrestricted \(\sup\mathcal R_\star<\infty\) is killed.**

**This is a counterexample to the boxed instantaneous
estimate. It is not a singular Navier–Stokes solution.
Ordinary NS is not solved. Soft X silent.**

Killed inequality (one line; every symbol
defined on [`LEMMA-STAR-STATEMENT.md`](LEMMA-STAR-STATEMENT.md)):
there is no finite \(C_{\mathrm{geom}}\) such that
\((T_c)_+^2\le C_{\mathrm{geom}}\,\mathcal D_s E Y\)
for every real, mean-zero, divergence-free
\(v\) on \(\mathbb{T}^3\) with \(\mathcal D_s>0\).
Here \(E=\|v\|_2^2\), \(Y=\|Av\|_2^2\),
\(\Lambda=Y/X\), \(\mathcal D_s=Z-\Lambda Y\),
\(T_c=M-\Lambda N\),
\(\mathcal R_\star=(T_c)_+^2/(\mathcal D_s E Y)\).

The named kill of leftover 4 was
\(\mathcal R_\star(v_n)\to\infty\).
That sequence sits. A finite sample is not this.
\(K\approx 0.641\) and grow-\(s\) \(K\approx 0.456\)
are not this.

Need★ cannot repair the same unrestricted bound
unless its hypotheses or conclusion change.
H1 and the axisymmetric shell door are other
integrals. Do not glue.

Specialist review of the all-\(n\) \(T_c\) identity
is still pending. The live evaluators already
reproduce the identity on \(n=1,\dots,10\).
That is not a proof assistant.

Derivation: [`math/ns_attacks/LEMMA_STAR_GROWING_LAYER_COUNTEREXAMPLE.md`](math/ns_attacks/LEMMA_STAR_GROWING_LAYER_COUNTEREXAMPLE.md).
Machine: `scripts/ns_attacks/verify_pr24_closure_review.py`
Audit: `results/pr24_closure_review/audit.json`
Locked statement: [`LEMMA-STAR-STATEMENT.md`](LEMMA-STAR-STATEMENT.md).
Tape: [`YES-NO-OPEN.md`](YES-NO-OPEN.md).

---

## The family

\[
\psi(x,y)=\cos x+\cos(x+y)+\cos(2x+y),
\qquad
U=(-\psi_y,\psi_x),
\]

\[
v_n(x,y,z)=D_n(z)\,(U_1(nx,ny),U_2(nx,ny),0),
\qquad
D_n(z)=\sum_{j=-n}^{n}e^{ijz}.
\]

Complete Fourier coefficients:

\[
\widehat v_n(nr_1,nr_2,j)
=
\frac{i}{2}(-r_2,r_1,0),
\quad
r\in\{\pm(1,0),\pm(1,1),\pm(2,1)\},
\quad
\lvert j\rvert\le n.
\]

They are real-field coefficients
(\(\widehat v(-k)=\overline{\widehat v(k)}\)),
mean-zero, and divergence-free.
At least two eigenvalues carry mass, so
\(\mathcal D_s>0\).
The packet changes shape with \(n\).
It is not a uniform Fourier dilation of one field.

Energy: \(E_n=4(2n+1)\).

---

## Side-conditions from the reason page

[`LEMMA-STAR-REASON.md`](LEMMA-STAR-REASON.md)
is a map, not the kill. The kill-relevant
conditions written there, and on the
statement it points to, are these.
Map comments (HH→L diagnostic, do not
merge \(0.71\), do not start H1) are
not extra gates on the boxed claim.

| Condition | \(v_n\) |
|---|---|
| Unaugmented fields on \(\mathbb{T}^3\) | **YES.** |
| Real (\(\widehat v(-k)=\overline{\widehat v(k)}\)) | **YES.** |
| Mean-zero | **YES.** |
| Divergence-free | **YES.** |
| Finite Fourier support (hence \(C^\infty\)) | **YES.** |
| \(\mathcal D_s>0\) (not one shell) | **YES.** Two eigenvalues carry mass. |
| \(\mathcal R_\star=(T_c)_+^2/(\mathcal D_s E Y)\) | **YES.** That is the quotient that diverges. |
| Keep \(\mathrm{Im}\); signed total, not \(\lvert\mathrm{Im}\rvert\) | **YES.** \(T_c=3n^5(3n^2+3n+1)>0\). |
| One shell is vacuous, not this kill | **YES.** Not one shell. |
| Not a uniform Fourier dilation | **YES.** Shape changes with \(n\). |
| No extra field / no \(K(t)\) in the PDE | **YES.** |

Admissible for the boxed claim.
The evaluators match. That is the kill
of unrestricted \(\sup\mathcal R_\star<\infty\).

---

## Signed seed and the vertical factor

The planar seed has complete signed transfers
\(3/4\), \(-1\), \(1/4\) on eigenvalues \(1,2,5\).
Its energy transfer and \(N\) vanish. Its \(M=3\).

Separation of \(D_n(z)\), including every cross
derivative, cancels the terms paired with \(U\)
and \(A_h U\). The surviving term is paired with
\(A_h^2 U\). The vertical cubic is
\(\langle D_n^3\rangle\), written as
a three-line sum so a reviewer does
not reconstruct it:

\[
\langle D_n^3\rangle
=
\#\{(a,b)\in\mathbb{Z}^2:
\lvert a\rvert,\lvert b\rvert,\lvert a+b\rvert\le n\}
=
\sum_{a=0}^{n}(2n-a+1)
+
\sum_{a=-n}^{-1}(2n+a+1)
=
3n^2+3n+1.
\]

\[
N(v_n)=0,
\qquad
T_c(v_n)=3n^5\langle D_n^3\rangle
=3n^5(3n^2+3n+1)>0.
\]

Keep \(\mathrm{Im}\). The signed total is retained.

---

## Elementary divergence

For every integer \(n\ge 1\):

\[
E_n=4(2n+1)\le 12n,
\qquad
\lambda_{\max}\le 6n^2,
\qquad
T_c\ge 9n^7,
\]

\[
Y_n\le 36n^4 E_n,
\qquad
0<\mathcal D_{s,n}\le Z_n\le 216n^6 E_n.
\]

Therefore

\[
\mathcal R_\star(v_n)
=
\frac{(T_c)_+^2}{\mathcal D_s E Y}
\ge
\frac{81n^{14}}{216\cdot 36\cdot 12^3 n^{13}}
=
\frac{n}{165888}
\to\infty.
\]

Any proposed finite \(C_{\mathrm{geom}}\) fails for
\(n>165888\,C_{\mathrm{geom}}\).
The sharper moment asymptotic
\(\mathcal R_\star(v_n)/n\to 496125/411555776>0\)
is not required for the kill.

---

## Live evaluators (not a second claim)

`scripts/ns_attacks/stokes_moments.py` and
`scripts/ns_lemma_star_core.py` both give:

| \(n\) | modes | \(N\) | \(T_c\) | \(\mathcal R_\star\) |
|--:|--:|--:|--:|--:|
| 1 | 18 | 0 | 21 | 0.001398359660043 |
| 2 | 30 | 0 | 1824 | 0.002574888688615 |
| 3 | 42 | 0 | 26973 | 0.003771825398057 |
| 4 | 54 | 0 | 187392 | 0.004972851263004 |

Through \(n=10\), \(T_c\) matches the closed form,
\(N=0\), \(\mathcal D_s>0\), and \(\mathcal R_\star/n\)
falls toward \(496125/411555776\).
Live Stokes was not overwritten.

---

## What this does not do

- It does not construct a blowup of NSE.
- It does not kill H1 or \(\int\rho_j\).
- It does not prove the exact-shell bound.
- It does not make Need★ a theorem.
- It does not put \(K(t)\) in the PDE.
- It does not turn A into B.

---

## Status

| Item | Verdict |
|---|---|
| Unrestricted \(\sup\mathcal R_\star<\infty\) | **NO.** Killed by \(v_n\). |
| Finite \(0.641\) / \(0.456\) as this kill | **NO.** Different objects. |
| Need★ as a repair of that same box | **NO** unless the claim changes. |
| Replacement energy-budget closure | **OPEN.** |
| Ordinary NS | **OPEN.** |
| Specialist reading of the \(T_c\) identity | **pending** |

---

## Specialist break lines

Full answers:
[`PR24-SPECIALIST-BREAK.md`](PR24-SPECIALIST-BREAK.md).

**1.** The identity a specialist can
still break is
\(T_c(v_n)=3n^5(3n^2+3n+1)\).
\(\langle D_n^3\rangle\) is a
three-line sum for general \(n\),
brute-checked through \(n=20\).
Live evaluators match the product
on \(n=1,\dots,10\), not merely
\(n\le 8\).

**2.** \(\mathcal D_s(v_n)>0\) for
every \(n\ge 1\): eigenvalues
\(n^2\) and \(2n^2\) both carry
mass. Computed rows are a check.

**3.** Amplitude invariance and a
global Plancherel constant do not
change the sign of
\(\mathcal R_\star\to\infty\).
The \(n\) in \(U(nx,ny)\) is part
of the family, not a later
normalization.

**4.** Instantaneous admissible
class, not a trajectory. Not a
Navier–Stokes solution. Not a
blowup.

**16–17.** The verifier checks live
moments and reads grow-\(s\) JSON.
It does not prove all-\(n\) \(T_c\).
If it is deleted, the elementary
lower bound \(\mathcal R_\star\ge n/165888\)
remains human-checkable once the
\(T_c\) identity is granted.

**18–20.** No replacement inequality
is displayed. Leftover 4 is OPEN.
A true \(4/3\) feeds no continuation
criterion: not BKM, not
\(\int\|Au\|_2^2\,dt<\infty\).

NS not solved. The boxed unrestricted ★ is dead.
The door that remains is a different closure.
