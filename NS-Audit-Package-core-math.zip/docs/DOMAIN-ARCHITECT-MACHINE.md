# Domain Architect machine (the experiment)

DA is an **anti-bullshit device**.

You do not have to know the chops. Domain Architect sets the math of the **process**. Ordinary AI is the generator. Scripts are the checker. You are the operator.

A sentence sits only if it names a slot and a check that could kill it. Fake passes, glue, slogans, and “unfalsifiable might be true” are the thing it is built to refuse. Open is allowed. Fail is allowed.

This is not “DA unifies the forces.” That stay is still shelved. This is: how far can an operator who is not a specialist go with ordinary AI, if every claim is forced into a slot and a fail-able check.

That is the valuable datum. It is also the shape of “use AI to work on problems,” not “AI said it is solved.”

The paper: [`docs/DA-PAPER.md`](DA-PAPER.md).

---

## What DA decided (the setup)

A **domain** is a pair \((X,V)\):

- \(X\) — one mathematical object (one PDE, one matrix, or one score)
- \(V\) — a verdict map from a proposal to \(\{\mathrm{pass},\mathrm{fail},\mathrm{open}\}\)

A **proposal** is a finite string the AI is allowed to emit: a lemma, a numerical check, a subset of knobs, a forbidden-move report. Not a vibe.

A **run** is \((d,p,v)\): domain, proposal, verdict. The log is the experiment.

Meta-success is **not** a solved PDE. It is

\[
S_{\mathrm{meta}}=\bigl(N_{\mathrm{scored}},\,N_{\mathrm{fail}},\,N_{\mathrm{pass}},\,N_{\mathrm{open}}\bigr)
\]

plus a list of any open item that later got a stronger lemma. If the AI cannot be scored, the machine failed, not the operator.

---

## Slots DA will accept

| Slot | Object \(X\) | What the AI may propose | Checker \(V\) |
|---|---|---|---|
| **A** | \(Q_1\) NS, \(\varepsilon>0\) | Energy identity, short Galerkin run | `augmented_ns_verify.py`, E1–E5 |
| **B** | Classical NS, keep \(1/r^4\) | LP / Bony / Ring / tube lemmas | `track_b_lemmas.py`. Identities may **pass**. Domain B stays **open**. Regularity has no pass. |
| **Q** | Inverse-GCD | Bridge*, Theorem P, \(H_N\ge-1\), Goldbach-shaped \(R\ge-2/9\) | `spectral_floor_explore.py` |
| **U** | Realization score \(R\) | Which knobs lock \(R\) | `unifier_exercise.py`, `unifier_combo.py` |

Glue is refused: A does not imply B, Q does not imply fluids, U does not unify the forces.

SFE, HB, prize packaging, and “I solved NS/RH” are not slots. They bounce.

---

## Forbidden closes (auto-fail)

The checker fails the proposal, without discussion, if it asserts any of:

- classical 3D NS is globally regular
- \(\lambda_{\min}(Q_N)>-1/2\) or \(\lambda_{\min}(\widetilde Q_N)>-1/2\) for all \(N\)
- Biot–Savart forces \(\cos\alpha_3\to 0\) for all data
- bounded \(\|\omega\|_2\) implies Beale–Kato–Majda
- \(\int\mathcal{E}\,dt<\infty\) kills cubic enstrophy blowup
- SFE / UHF / DHFA implies a fluids or coupling map
- Track A \(\Rightarrow\) Track B, or Bridge* \(\Rightarrow\) SND

Open is allowed. Fail is allowed. A fake pass is not.

---

## How you run it (no chops)

```
python3 scripts/da_machine.py status
python3 scripts/da_machine.py check
python3 scripts/da_machine.py classify --claim "the prime block of Q-tilde sits above -1/4"
python3 scripts/da_machine.py log --domain Q --claim "Theorem P" --verdict pass --note "script certificate"
```

`status` shows the slots and last feed age (stale if missing or \>24h; no network). `check` runs every checker that exists (`check B` stays **open** if the lemmas hold). `classify` is DA assigning a slot and a pre-verdict from the claim text. `tracka` scores the Track A lemmas (`docs/TRACK-A-LEMMAS.md`). Theorem A is this PDE only. Uniform \(H^1\) as \(\varepsilon\to 0\) stays open. `trackb` scores the Track B lemmas (`docs/TRACK-B-LEMMAS.md`). `sm` takes the Standard Model Lagrangian as the object and realizes Einstein\(+T_{\mathrm{SM}}\) (`docs/DA-SM-LAGRANGIAN.md`). `smbreak` opens that Lagrangian past the five poster blocks and puts it back (`docs/DA-SM-BREAK.md`). `team` seats the published results and the measurements (`docs/DA-DREAM-TEAM.md`). The combined name list is `docs/DA-THINK-TANK.md`. A vote cannot close a theorem. `session` sits them as colleagues and lets them talk (`docs/DA-SESSION.md`). A conversation cannot close regularity. `living` seats living now-bench papers and asks where now / whether \(X\) can close (`docs/DA-LIVING.md`). Possible stays open. Impossible is not a theorem. `leads` asks every seated kingdom for one lead (`docs/DA-LEADS.md`). Asking is allowed. Glue is refused. `lineage` winds \(\mathcal{L}_{\mathrm{SM}}\) backwards through prior theories and forwards through the same dots (`docs/DA-SM-LINEAGE.md`). `harmonic` types the distinct mathematical objects that share the English word (`docs/DA-HARMONIC-VOCAB.md`). Desk coverage can pass. One object, a finished field, \(F\), HB, or a regularity close cannot. `ground` takes “spectrum, not a bag of couplings” as the destination, reconstructs from \((X,D,\sigma,\mathrm{Rep})\), ablates, and seats Einstein / Tesla / Feynman as a *program review* (`docs/DA-GROUND.md`). Naming HB is allowed. A review cannot write \(F\). `now` lists seated living papers and a watch list (`docs/DA-NOW.md`). Genius is not a slot. `feed` scans GWTC, LHC, PDG, and arXiv (`docs/DA-FEED.md`). `agent` pulls both: propose, scan, score, alert (`docs/DA-AGENT.md`). Agent-shaped. Not a closer. Latest data belongs and does not write \(X\). `next` names the wall, names the target, and translates an operator sentence into math (`docs/DA-NEXT.md`). Target on B is \(X\), not \(F\). A suggestion is not a close. Empty `next`, or `nowwhat`, asks the leftover papers what they would try, then history what it would do now (`docs/DA-NOWWHAT.md`). Papers, not minds. Not a vote. Not a séance. Not ChatGPT freestyle. `hunt` (also `chain`) walks the scored residual graph and keeps the object in a window (`docs/DA-HUNT.md`). `look` (also `window`) opens that pane anytime. `from` (also `mine`) walks this desk’s scored steps to the break and names what a regularity proof still needs (`docs/DA-FROM.md`). `proof --problem NS` or `proof --problem A` or `proof --problem RH` or `proof --problem YM` or `proof --problem BSD` writes the aimed chain from the ground floor (`docs/NS-PROOF-CHAIN.md`, `docs/A-PROOF-CHAIN.md`, `docs/RH-PROOF-CHAIN.md`, `docs/YM-PROOF-CHAIN.md`, `docs/BSD-PROOF-CHAIN.md`). The operator names the problem. Asking is the product. Track Q is not RH and not BSD. The WRITE line is the attempt. A generator may phrase a candidate. The checker scores it. `done` answers whether that emit is a finish (`docs/DA-DONE.md`). Theorem A is done for this PDE. Classical leftover is not. Hearing A closed is not Navi Stokes. `study` scores the asks pointed at DA (`docs/DA-STUDY.md`). Write yes. Finish leftover no. Support is not a solver pass. `q` opens the inverse-GCD paper (`docs/DA-Q.md`): sitting floors, Q6 hygiene, Q7 not seated, Goldbach-shaped R>=-2/9 as a corollary of Theorem P (not the integer conjecture). Q is not RH and not B. `repair --job A` (or `SND`, or `H`) takes work already on the desk, names the fault, and names the repair write (`docs/DA-REPAIR.md`). Theorem A is this PDE. Exporting A onto B is not a repair. `attempt` takes the best \(Q_1\)+renormalization work and the furthest RH attempt, seats the field papers, and does the legal write (`docs/DA-ATTEMPT.md`). A vote does not complete a missing line. Track Q is not RH. `brute` says why a supercomputer or quantum device cannot try every permutation and emit the leftover (`docs/DA-BRUTE.md`). A finite list is legal. Try-every is not a write. `picture` seats the published treatise in each area and prints the next write (`docs/DA-PICTURE.md`). A survey is a map. Seeing the whole field is not the estimate. Genius is not a slot. `pipe` adds a now-bench of typed live streams and puts every desk verdict under a killer (`docs/DA-PIPE.md`). It does not replace the dream team. Primes do not update black holes. `desk` writes the whole roster and types the corpus method (`docs/DA-DESK.md`): DA draws from published papers, pairs two or three, and scores the sentence. A pairing does not write \(F\). `compute` lists techniques already wired, legal to borrow, or refused as a fake close (`docs/DA-COMPUTE.md`). `alert` writes a plain-language note plus what to do next when a watched claim flips (`docs/DA-ALERT.md`). Catalogs do not text you. A phone sender is optional (`DA_ALERT_WEBHOOK`). `cosmos` loads the official CosmoEvolution 3D sixteen and runs the isolated screen (`docs/COSMO-SIXTEEN.md`, `docs/DA-COSMOS-DRILL.md`). `sixteen` identifies a reconstructed 4×4 list, runs each slot, and names the 16th as \(R\) (`docs/DA-SIXTEEN.md`). `fingers` does five-finger DA on the realization line and recurses (`docs/DA-FINGERS.md`). `bhand` prints the unaugmented-NS five-finger map (identities, spindle, after the spindle, Need★, restricted class). Cosmo `fingers` stays the other book. MAP, not a close (`docs/DA-NS-FIVE-FINGER.md`). `fate` gives each of the reconstructed 16 a category and a general fate, then breaks the pieces (`docs/DA-SIXTEEN-FATE.md`). `how` lists the only legal reasons a typed catalog can say “possible” and emit a finite \(X\) (`docs/DA-HOW-IT-KNEW.md`). `flush` ranks combinations by Born weight (`docs/DA-FLUSH.md`). `wave` adds superposition / entanglement / collapse / falsification rules without touching A/B/Q (`docs/DA-WAVE.md`). `game` runs Shapley on the score versus the unifier-claim game (`docs/DA-GAME.md`). `screen` runs published unification claims through gauge3 vs nature4 (`docs/DA-SCREEN.md`). `gq` starts at gravity + quantum and names what is coupled (`docs/DA-GRAVITY-QUANTUM.md`). `separate` runs each pair, published claim, reconstructed slot, and Cosmo slot alone (`docs/DA-SEPARATE.md`). `log` writes one run into `results/da_machine_log.json`.

You point ordinary AI at one slot. It proposes. You run `classify` and `check`. The log is the record of how far this process got.

---

## What would count as the machine working

- The AI’s sentence lands in exactly one slot.
- A script returns pass or fail in finite time.
- A fail is recorded, not rewritten into a pass.
- An open item stays open until a real lemma or a real counterexample.

That is already a result about AI-for-problems, whether or not any PDE closes.