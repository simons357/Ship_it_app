# Dream team, from beyond the digital divide

`python3 scripts/da_machine.py team`

The divide is not “AI vs human chat.” It is **this desk**
versus **paper and experiment**. The dream team is the
published results and the measurements that already constrain
the slots. Another model is still on the digital side.

A team is not a vote. A vote cannot collapse the waveform.

---

## Who sits

| Member | Slot | Side | Settles | Cannot |
|---|---|---|---|---|
| Leray | B | paper | energy, \(\int X<\infty\) | \(X\in L^\infty\) from that |
| Beale–Kato–Majda | B | paper | \(\int\|\omega\|_\infty<\infty\) | BKM-from-\(L^2\) |
| Caffarelli–Kohn–Nirenberg | B | paper | partial regularity | no blowup |
| Constantin–Fefferman | B | paper | depletion *if* aligned | all-data \(\cos\alpha_3\to 0\) |
| Ladyzhenskaya | A | paper | modified NS, \(\varepsilon>0\) | \(\varepsilon\to 0\), A\(\Rightarrow\)B |
| Einstein | U | paper | \(G_{\mu\nu}+\Lambda g=8\pi G\,T_{\mathrm{SM}}\) | values of \(G,\Lambda\) |
| Weinberg | U | paper | the \(W^3\)–\(B\) rotation | \(\theta_W\) from topology |
| experiment / PDG | U | nature | the numbers \(\mathcal{L}\) consumes | why those numbers |
| neutrino / cosmology | U | nature | \(\sum m_\nu\) bound; \(\Lambda\) seen | Cosmo 0.06 eV as \(F\) |
| operator | meta | desk | one sentence, one slot, one check | needing chops |

SFE, HB, Cosmo Superagent, and “the app said so” do not get a
chair.

---

## What they say in common (not a close)

- **B:** B4c on CONC, energy-class \(T\) on SPREAD, B8 clock. Glue sketch written. Frozen low-\(j_*\) has an energy ceiling. Climbing: slow dies, fast sits. NS did not force a saving \(c\) (B11d). Climb sketch is not an a priori (B11e). Longer \(n=32\) past room time did not produce \(c=8\) (B13e). Geometry: identity pass; CONC not depleted; CF conditional. Stretching budget is not an a priori (B15e). Fluids: net cubic cancels; visc owns this ensemble; \(L^2\) is not BKM. Angular \(1/r^2\) does not dominate \(I_{\mathrm{tube}}\). Coherent CONC: signed-strain blob nets; working-box cubic not live. Field occupation: clock stays CONC. Field glue: \(j_*=2\) model grows, NS packet falls. DNS is not an a priori (B13f). Tube budget is not an a priori (B5f). Geometry is not an a priori (B14d). Enstrophy balance is not an a priori (B16e). Coherent blob is not an a priori (B17e). Field occupation is not an a priori (B18e). Field glue is not an a priori (B19e). NS climb is not an a priori (B20e). Climb sketch is not an a priori (B21e). Finer box is not an a priori (B22e). Finer DNS is not an a priori (B23e). Leftover close is not an a priori (B34e). Regularity leftover is not an a priori (B35e). Regularity stays open. The PDE is not being tuned.
- **A:** Leave Ladyzhenskaya on A.
- **U:** Stop breaking \(\mathcal{L}_{\mathrm{SM}}\). Keep Einstein \(+T_{\mathrm{SM}}\). Produce lives outside the poster.
- **Q:** Arithmetic only. No Bridge* \(\to\) SND.

Glue refused.

That is the same next write the machine already had. The
team did not invent a new unifier. It confirmed which
closes are already illegal.

They sit as colleagues and talk in
[`docs/DA-SESSION.md`](DA-SESSION.md).
`python3 scripts/da_machine.py session`
A conversation is not a close.

The living now-bench talks in
[`docs/DA-LIVING.md`](DA-LIVING.md).
`python3 scripts/da_machine.py living`
Possible to close \(X\) stays open.

The **now-bench** — current collaborations and data forms —
is additive and lives in [`docs/DA-PIPE.md`](DA-PIPE.md).
It does not unseat this table.