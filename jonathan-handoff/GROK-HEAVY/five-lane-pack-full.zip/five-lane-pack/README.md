# five-lane-pack (full folder + tests)

Full folder plus tests: the original 11 PR #48 scripts, plus `counting_cs.py` / `attack9d_growing_io.py` so the lock tests import. Attacks 9A–9D are later; they are not the original five lanes.
NS is not solved. Lemma★ is OPEN.

## Scripts
1. stokes_moments.py — E, X, Y, Z, Λ, Tc, Ds, ratio_R_star_shape
2. attack9b_exact_shell_K.py — 9B K / aligned closing packet
3. __init__.py
4. lemma_star_near_shell_search.py
5. run_all_five.py — lanes 1–5 only
6. attack1_covariance.py
7. attack2_triad_k0_cstar.py
8. attack3_bony_hh_l.py
9. attack4_stokes.py
10. attack5_route2_kill.py
11. attack9_packet_fan.py

## Run
```bash
cd five-lane-pack
PYTHONPATH=scripts python3 -m pytest tests/test_ns_attacks_lemma_star.py -q
PYTHONPATH=scripts python3 scripts/ns_attacks/attack9b_exact_shell_K.py \
  --kmax 4 --trials 8 --refine 4 --seed 1390 --outdir /tmp/attack9b_exact_shell
```

ratio_R_star_shape is R★ = (Tc_+)² / (Ds E Y).
9B ε→0 limit equals K only for aligned, sign-selected z_β ∥ Π_β B(w,w).
A finite max K is not a proof.
