# Attack 9B results — 10 September 2026 (seed 1390)

Original completed run from PR #48. Not a proof. Kill lane LIVE. NS not solved.

- max K ≈ 0.641 at (α,β)=(4,8)
- controls_all_pass: true
- eps_limit_all_pass: true (aligned, sign-selected z_β)
- Finite sample max is not a kill of Lemma★

Files: attack9b.json, HEADLINE.md, run.log, K_by_ab_pair.png, R_star_eps_limit.png
